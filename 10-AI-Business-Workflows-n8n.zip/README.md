# 10 AI Business Automation Workflows for n8n

Ready-to-import n8n workflows powered by Claude AI. Each workflow includes setup instructions inside a Sticky Note.

## What's Inside

| # | Workflow | File | What It Does |
|---|---------|------|-------------|
| 1 | AI Lead Generator | `01-lead-generator.json` | Scrape any website, extract contacts & company data to Google Sheets |
| 2 | AI Blog Post Writer | `02-blog-post-writer.json` | Generate SEO-optimized blog posts with meta descriptions |
| 3 | AI Email Sequence Builder | `03-email-sequence-builder.json` | Create full email sequences (welcome, nurture, offer) |
| 4 | AI Social Media Generator | `04-social-media-generator.json` | Generate posts for Twitter, LinkedIn, Instagram, Facebook |
| 5 | AI Customer Review Analyzer | `05-review-analyzer.json` | Analyze reviews for sentiment, themes, and actionable insights |
| 6 | AI Invoice Processor | `06-invoice-processor.json` | Extract invoice data and save to Google Sheets automatically |
| 7 | AI Meeting Summarizer | `07-meeting-summarizer.json` | Summarize meetings with action items and decisions |
| 8 | AI SEO Keyword Research | `08-seo-keyword-research.json` | Generate keyword clusters with search intent and content ideas |
| 9 | AI Competitor Monitor | `09-competitor-monitor.json` | Daily monitoring of competitor websites with Telegram alerts |
| 10 | AI FAQ Bot Builder | `10-faq-bot-builder.json` | Generate 20 Q&A pairs + embeddable HTML widget + SEO schema |

## Quick Start

1. Open your n8n instance
2. Go to **Workflows** > **Import from File**
3. Select any `.json` file from this pack
4. Open the **Sticky Note** inside the workflow for setup instructions
5. Replace `YOUR_API_KEY` with your Anthropic API key ([get one here](https://console.anthropic.com))
6. Activate the workflow

## Requirements

- n8n (self-hosted or cloud) — [n8n.io](https://n8n.io)
- Anthropic API key — [console.anthropic.com](https://console.anthropic.com)
- Google account (for workflows #1 and #6 that use Google Sheets)
- Brave Search API key (for workflow #8, free tier available at [brave.com/search/api](https://brave.com/search/api))
- Telegram Bot (for workflow #9, create via [@BotFather](https://t.me/BotFather))

## Support

Each workflow has a Sticky Note with step-by-step setup instructions. If you need help, refer to the [n8n documentation](https://docs.n8n.io).

## License

For personal and commercial use. Do not resell as-is.
